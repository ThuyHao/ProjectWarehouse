create definer = root@localhost trigger configs_BEFORE_UPDATE
    before update
    on configs
    for each row
BEGIN
    SET NEW.updated_at = CURRENT_TIMESTAMP;
END;

